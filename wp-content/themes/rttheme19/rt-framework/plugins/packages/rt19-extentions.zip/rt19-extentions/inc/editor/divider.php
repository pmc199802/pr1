<?php
/*
*
* Seperator
*
*/
vc_map_update( 'vc_separator', array(
	'category'    => array(__( 'Content','rt_theme' ), __( 'Theme Addons','rt_theme' )),
));

//remove vc_row params
rt_vc_remove_param('vc_separator', array('color','el_width','el_class','style','accent_color','css','align','border_width'));

vc_add_param( 'vc_separator',array(
	'param_name'  => 'style',
	'heading'     => __( 'Style','rt_theme' ),
	'description' => __( 'Select a style','rt_theme' ),
	'type'        => 'dropdown',
	"value"       => array(
						__("Style One - Three Circle",'rt_theme') => "style-1",
						__("Style Two - Small Left Aligned Line",'rt_theme') => "style-2", 
						__("Style Three - With Down Arrow",'rt_theme') => "style-3", 						
						__("Style Four - Classic One Line",'rt_theme') => "style-4", 
						__("Style Five - Double Line",'rt_theme') => "style-5", 
						__("Style Six - Small Center Aligned Line",'rt_theme') => "style-6", 
					),
	'save_always' => true
));


vc_add_param( 'vc_separator', array(
	'param_name'  => 'color',
	'heading'     => __( 'Custom Color','rt_theme' ),
	'description' => __( 'Color of the border.','rt_theme' ),
	'type'        => 'colorpicker',
	"dependency"  => array(
						"element" => "style",
						"value" => array("style-2","style-4","style-5","style-6")
					), 
));

vc_add_param( 'vc_separator', array(
	'param_name'  => 'border_width',
	'heading'     => __( 'Custom Border Width','rt_theme' ),
	'description' => __( 'Set border width value (px)','rt_theme' ),
	'type'        => 'rt_number',
	"dependency"  => array(
						"element" => "style",
						"value" => array("style-2","style-4","style-5","style-6")
					),
));

vc_add_param( 'vc_separator', array(
	'param_name'  => 'margin_top',
	'heading'     => __( 'Custom Margin Top','rt_theme' ),
	'description' => __( 'Set margin top value (px) Default is 40px','rt_theme' ),
	'type'        => 'rt_number', 
));

vc_add_param( 'vc_separator', array(
	'param_name'  => 'margin_bottom',
	'heading'     => __( 'Custom Margin Bottom','rt_theme' ),
	'description' => __( 'Set margin bottom value (px) Default is 40px','rt_theme' ),
	'type'        => 'rt_number',
));

vc_add_param( 'vc_separator', array(
	'param_name'  => 'width',
	'heading'     => __( 'Custom Width','rt_theme' ),
	'description' => __( 'Set a custom width value (px,%)','rt_theme' ),
	'type'        => 'rt_number', 
));

vc_add_param( 'vc_separator',array(
	'param_name'  => 'id',
	'heading'     => __('ID','rt_theme' ),
	'description' => __('Unique ID','rt_theme' ),
	'type'        => 'textfield',
	'value'       => ''
));

vc_add_param( 'vc_separator',array(
	'param_name'  => 'class',
	'heading'     => __('Class','rt_theme' ),
	'description' => __('CSS Class Name','rt_theme' ),
	'type'        => 'textfield'
));

?>