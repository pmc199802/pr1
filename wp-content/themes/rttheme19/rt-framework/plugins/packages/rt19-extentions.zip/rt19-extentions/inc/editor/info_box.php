<?php
/*
*
* Info Box
*
*/ 

vc_map(
	array(
		'base'        => 'info_box',
		'name'        => __( 'Info Box','rt_theme' ),
		'icon'        => 'rt_theme info_box',
		'category'    => array(__( 'Content','rt_theme' ), __( 'Theme Addons','rt_theme' )),
		'description' => __( 'Adds a info box','rt_theme' ),
		'params'      => array(

							array(
								'param_name'  => 'content',
								'heading'     => __( 'Text','rt_theme' ),
								'description' => '',
								'type'        => 'textarea_html',
								'holder'      => 'div',
								'value'       => __( 'I am text block. Click edit button to change this text.','rt_theme' ),
								'holder'      => 'span',
								'save_always' => true
							),
 
							array(
								'param_name'  => 'style',
								'heading'     => __( 'Button Size','rt_theme' ),
								'type'        => 'dropdown',
								"value"       => array(
													__("Announcement","rt_theme")=>"announcement",
													__("Ok","rt_theme")=>"ok",
													__("Attention","rt_theme")=>"attention",
													__("Info","rt_theme")=>"info",
												), 
								'save_always' => true
							),

							array(
								'param_name'  => 'id',
								'heading'     => __('ID','rt_theme' ),
								'description' => __('Unique ID','rt_theme' ),
								'type'        => 'textfield',
								'value'       => ''
							),

							array(
								'param_name'  => 'class',
								'heading'     => __('Class','rt_theme' ),
								'description' => __('CSS Class Name','rt_theme' ),
								'type'        => 'textfield'
							),

						)
	)
);	

?>