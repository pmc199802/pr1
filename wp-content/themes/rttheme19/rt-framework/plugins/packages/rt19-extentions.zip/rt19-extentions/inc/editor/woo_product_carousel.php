<?php
/*
*
* WooCommerce Product Carousel 
*
*/ 

vc_map(
	array(
		'base'        => 'woo_product_carousel',
		'name'        => __( 'WooCommerce Product Carousel','rt_theme' ),
		'icon'        => 'rt_theme carousel',
		'category'    => array(__( 'Content','rt_theme' ), __( 'Theme Addons','rt_theme' ), 'WooCommerce'),
		'description' => __( 'Displays WooCommerce products as a carousel','rt_theme' ),
		'params'      => array(

 
							array(
								'param_name'  => 'id',
								'heading'     => __('ID','rt_theme' ),
								'description' => __('Unique ID','rt_theme' ),
								'type'        => 'textfield',
								'value'       => ''
							),

							array(
								'param_name'  => 'list_layout',
								'heading'     => __( 'Layout','rt_theme' ),
								"description" => __("Column width of an item. Percent of the visible part.",'rt_theme'),
								'type'        => 'dropdown',
								"value"       => array(
													"1/6" => "1/6", 
													"1/5" => "1/5", 
													"1/4" => "1/4",
													"1/3" => "1/3",
													"1/2" => "1/2",
													"1/1" => "1/1"
												),
								'save_always' => true
							),
 
  							array(
								'param_name'  => 'tablet_layout',
								'heading'     => __( 'Carousel Layout (Tablet)','rt_theme' ),
								"description" => __("Visible image count for each slide on medium screens.",'rt_theme'),
								'type'        => 'dropdown',
								"value"       => array(
													__("Default","rt_theme") => "",
													"1/1" => "1",
													"1/2" => "2",													
													"1/3" => "3",													
													"1/4" => "4",													
													"1/5" => "5",													
													"1/6" => "6"	
												),
							),


 							array(
								'param_name'  => 'mobile_layout',
								'heading'     => __( 'Carousel Layout (Mobile)','rt_theme' ),
								"description" => __("Visible image count for each slide on small screens.",'rt_theme'),
								'type'        => 'dropdown',
								"value"       => array(
													__("Default","rt_theme") => "",
													"1/1" => "1",
													"1/2" => "2",													
													"1/3" => "3",													
													"1/4" => "4",													
													"1/5" => "5",													
													"1/6" => "6"	
												),
							),
							
							array(
								'param_name'  => 'max_item',
								'heading'     => __('Amount of item to display','rt_theme' ),
								'type'        => 'rt_number',
								'value'       => '10',
								'save_always' => true
							),


							array(
								'param_name'  => 'nav',
								'heading'     => __( 'Navigation Arrows','rt_theme' ),
								'type'        => 'dropdown',
								"value"       => array(
													__("Enabled","rt_theme") => "true", 
													__("Disabled","rt_theme") => "false"													
												),
								'save_always' => true						
							),

							array(
								'param_name'  => 'dots',
								'heading'     => __( 'Navigation Dots','rt_theme' ),
								'type'        => 'dropdown',
								"value"       => array(
													__("Enabled","rt_theme") => "true", 
													__("Disabled","rt_theme") => "false"												
												),
								'save_always' => true						
							),

							array(
								'param_name'  => 'autoplay',
								'heading'     => __( 'Auto Play','rt_theme' ),
								'type'        => 'dropdown',
								"value"       => array(												
													__("Disabled","rt_theme") => "false",
													__("Enabled","rt_theme") => "true"
												),
								'save_always' => true						
							),

							array(
								'param_name'  => 'timeout',
								'heading'     => __('Auto Play Speed (ms)','rt_theme' ),
								'type'        => 'rt_number',
								'value'       => "",
								"description" => __("Auto play speed value in milliseconds. For example; set 5000 for 5 seconds",'rt_theme'),
								"dependency"  => array(
													"element" => "autoplay",
													"value" => array("true")
												),
							),
							
							array(
								'param_name'  => 'list_orderby',
								'heading'     => __( 'List Order By','rt_theme' ),
								"description" => __("Sorts the posts by this parameter",'rt_theme'),
								'type'        => 'dropdown',
								"value"       => array(
													__('Date','rt_theme') => 'date',
													__('Author','rt_theme') => 'author',
													__('Title','rt_theme') => 'title',
													__('Modified','rt_theme') => 'modified',
													__('ID','rt_theme') => 'ID',
													__('Randomized','rt_theme') => 'rand',
												),
								'save_always' => true
							),

							array(
								'param_name'  => 'list_order',
								'heading'     => __( 'List Order','rt_theme' ),
								"description" => __("Designates the ascending or descending order of the list_orderby parameter",'rt_theme'),
								'type'        => 'dropdown',
								"value"       => array(
													__('Descending','rt_theme') => 'DESC',
													__('Ascending','rt_theme') => 'ASC',
												),
								'save_always' => true
							),

							array(
								'param_name'  => 'categories',
								'heading'     => __( 'Categories','rt_theme' ),
								"description" => __("List posts of selected categories only.",'rt_theme'),
								'type'        => 'dropdown_multi',
								"value"       => array_merge(array(__('All Categories','rt_theme')=>""),array_flip(rt_get_woo_product_category_ids())),
							),
			
						)
	)
);	

?>