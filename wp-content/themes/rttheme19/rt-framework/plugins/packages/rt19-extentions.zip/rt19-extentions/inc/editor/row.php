<?php
/*
*
* Rows
*
*/
vc_map_update( 'vc_row', array(
	'category'    => array(__( 'Structure','rt_theme' ), __( 'Theme Addons','rt_theme' )),
));

//remove vc_row params
rt_vc_remove_param('vc_row', array('video_bg','video_bg_url','video_bg_parallax','full_width','bg_color','font_color','padding','margin_bottom','bg_image','bg_image_repeat','el_class','css','parallax','parallax_image','el_id','gap','equal_height','content_placement','parallax_speed_video','parallax_speed_bg'));

//remove vc_row_inner params
rt_vc_remove_param('vc_row_inner', array('video_bg','video_bg_url','video_bg_parallax','full_width','bg_color','font_color','padding','margin_bottom','bg_image','bg_image_repeat','el_class','css','parallax','parallax_speed_video','parallax_speed_bg','parallax_image','el_id','gap','content_placement','columns_placement','equal_height','full_height'));


//general options
vc_add_param( 'vc_row', array(
	'param_name'  => 'rt_row_background_width',
	'heading'     => __( 'Row Background Width','rt_theme' ),
	'description' => __( 'Select a pre-defined width for the row background','rt_theme' ),
	'type'        => 'dropdown',
	"value"       => array(
						__("Default Width",'rt_theme') => "default",
						__("Full Width",'rt_theme') => "fullwidth",
					),				
	
	'save_always' => true
));

vc_add_param( 'vc_row', array(
	'param_name'  => 'rt_row_content_width',
	'heading'     => __( 'Row Content Width','rt_theme' ),
	'description' => __( 'Select a pre-defined width for the row content','rt_theme' ),
	'type'        => 'dropdown',
	"value"       => array(
						__("Default Width",'rt_theme') => "default",
						__("Full Width",'rt_theme') => "fullwidth",
					),				
	
	"dependency"  => array(
							"element" => "rt_row_background_width",
							"value" => array("fullwidth")
						),		
	'save_always' => true
));


vc_add_param( 'vc_row', array(
	'param_name'  => 'rt_row_style',
	'heading'     => __( 'Row Style','rt_theme' ),
	'description' => __( 'Select a color scheme for the row.','rt_theme' ),
	'type'        => 'dropdown',
	"value"       => array(
						__("Color Set 1",'rt_theme') => "default-style",
						__("Color Set 2",'rt_theme') => "alt-style-1",
						__("Color Set 3",'rt_theme') => "alt-style-2",
						__("Color Set 4",'rt_theme') => "light-style",
					),				
	'save_always' => true
));

vc_add_param( 'vc_row_inner', array(
	'param_name'  => 'rt_row_style',
	'heading'     => __( 'Row Style','rt_theme' ),
	'description' => __( 'Select a color scheme for the row.','rt_theme' ),
	'type'        => 'dropdown',
	"value"       => array(
						__("Global",'rt_theme') => "global-style",
						__("Color Set 1",'rt_theme') => "default-style",
						__("Color Set 2",'rt_theme') => "alt-style-1",
						__("Color Set 3",'rt_theme') => "alt-style-2",
						__("Color Set 4",'rt_theme') => "light-style",
					),				
	'save_always' => true
));


rt_vc_add_param( array('vc_row','vc_row_inner'), array(
	'type' => 'dropdown',
	'heading' => _x( 'Content placement', 'Admin Panel','rt_theme' ),
	'param_name' => 'rt_column_placement',
	'value' => array(		
		_x( 'Top', 'Admin Panel','rt_theme' ) => 'top',
		_x( 'Middle', 'Admin Panel','rt_theme' ) => 'middle',
		_x( 'Bottom', 'Admin Panel','rt_theme' ) => 'bottom',
	),
	'description' => _x( 'Select the content position within the content holder', 'Admin Panel','rt_theme' ),
));


rt_vc_add_param( array('vc_row','vc_row_inner'), array(
	'param_name'  => 'rt_row_borders',
	'heading'     => __( 'Row Borders','rt_theme' ),
	'type'        => 'checkbox',
	"value"       => array(
						__("Top Border",'rt_theme') => "top",
						__("Bottom Border",'rt_theme') => "bottom",
					),				
	'save_always' => true
));

vc_add_param( 'vc_row', array(
	'param_name'  => 'rt_overlap',
	'heading'     => __( 'Overlap','rt_theme' ),
	'type'        => 'checkbox',
	"value"       => array(
						__("Overlap to the previous row",'rt_theme') => "true",
					),				
));

rt_vc_add_param( array('vc_row','vc_row_inner'), array(
	'param_name'  => 'rt_grid',
	'heading'     => __( 'Grid View','rt_theme' ),
	'type'        => 'checkbox',
	"value"       => array(
						__("Display the columns as a grid with borders.",'rt_theme') => "true",
					),
));

rt_vc_add_param( array('vc_row','vc_row_inner'), array(
	'param_name'  => 'rt_equal_heights',
	'heading'     => __( 'Equal Heights','rt_theme' ),
	'type'        => 'checkbox',
	"value"       => array(
						__("Make the column heights equal.",'rt_theme') => "true",
					),
));

rt_vc_add_param( array('vc_row','vc_row_inner'), array(
	'param_name'  => 'rt_col_anim',
	'heading'     => __( 'Column Animations','rt_theme' ),
	'type'        => 'checkbox',
	"value"       => array(
						__("Animate columns when first appeared",'rt_theme') => "true",
					),
));

rt_vc_add_param( array('vc_row','vc_row_inner'), array(
	'param_name'  => 'rt_row_height',
	'heading'     => __( 'Minimum Row Height','rt_theme' ),
	'description' => __( 'You can set a minimum height for the row','rt_theme' ),
	'type'        => 'rt_number'
)); 

rt_vc_add_param( array('vc_row','vc_row_inner'), array(
	'param_name'  => 'rt_row_paddings',
	'heading'     => __( 'Paddings','rt_theme' ),
	'description' => __( 'Remove/add paddings (gaps) around the row.','rt_theme' ),
	'type'        => 'dropdown',
	"value"       => array(
						__("Add Paddings",'rt_theme') => "true", 
						__("No Paddings",'rt_theme') => "false",
					),						
	'group'       => __( 'Paddings','rt_theme' ),
	'save_always' => true
));

$default_padding_var = get_theme_mod(RT_THEMESLUG.'_layout') == "layout1" || get_theme_mod(RT_THEMESLUG.'_layout') == "layout2" ? " 25px" : " 35px";

/**
 * parent row paddings
 */
rt_vc_add_param( array('vc_row'), array(
	'param_name'  => 'rt_padding_top',
	'heading'     => __( 'Padding Top','rt_theme' ),
	'description' => __( 'Set padding top value (px,%) Default is'.$default_padding_var,'rt_theme' ),
	'type'        => 'rt_number',
	'group'       => __( 'Paddings','rt_theme' ),
	"dependency"  => array(
							"element" => "rt_row_paddings",
							"value" => array("true")
						),		
));

rt_vc_add_param( array('vc_row'), array(
	'param_name'  => 'rt_padding_bottom',
	'heading'     => __( 'Padding Bottom','rt_theme' ),
	'description' => __( 'Set padding bottom value (px,%) Default is'.$default_padding_var,'rt_theme' ),
	'type'        => 'rt_number',
	'group'       => __( 'Paddings','rt_theme' ),
	"dependency"  => array(
							"element" => "rt_row_paddings",
							"value" => array("true")
						),	
));

rt_vc_add_param( array('vc_row'), array(
	'param_name'  => 'rt_padding_left',
	'heading'     => __( 'Padding Left','rt_theme' ),
	'description' => __( 'Set padding left value (px,%) Default is 10px','rt_theme' ),
	'type'        => 'rt_number',
	'group'       => __( 'Paddings','rt_theme' ),
	"dependency"  => array(
							"element" => "rt_row_paddings",
							"value" => array("true")
						),	
));

rt_vc_add_param( array('vc_row'), array(
	'param_name'  => 'rt_padding_right',
	'heading'     => __( 'Padding Right','rt_theme' ),
	'description' => __( 'Set padding right value (px,%) Default is 10px','rt_theme' ),
	'type'        => 'rt_number',
	'group'       => __( 'Paddings','rt_theme' ),
	"dependency"  => array(
							"element" => "rt_row_paddings",
							"value" => array("true")
						),	
));	

/**
 * inner row paddings
 */
rt_vc_add_param( array('vc_row_inner'), array(
	'param_name'  => 'rt_padding_top',
	'heading'     => __( 'Padding Top','rt_theme' ),
	'description' => __( 'Set padding top value (px,%) Default is 0px','rt_theme' ),
	'type'        => 'rt_number',
	'group'       => __( 'Paddings','rt_theme' ),
	"dependency"  => array(
							"element" => "rt_row_paddings",
							"value" => array("true")
						),		
));

rt_vc_add_param( array('vc_row_inner'), array(
	'param_name'  => 'rt_padding_bottom',
	'heading'     => __( 'Padding Bottom','rt_theme' ),
	'description' => __( 'Set padding bottom value (px,%) Default is 0px','rt_theme' ),
	'type'        => 'rt_number',
	'group'       => __( 'Paddings','rt_theme' ),
	"dependency"  => array(
							"element" => "rt_row_paddings",
							"value" => array("true")
						),	
));


rt_vc_add_param( array('vc_row_inner'), array(
	'param_name'  => 'rt_padding_left',
	'heading'     => __( 'Padding Left','rt_theme' ),
	'description' => __( 'Set padding left value (px,%) Default is 0px','rt_theme' ),
	'type'        => 'rt_number',
	'group'       => __( 'Paddings','rt_theme' ),
	"dependency"  => array(
							"element" => "rt_row_paddings",
							"value" => array("true")
						),	
));

rt_vc_add_param( array('vc_row_inner'), array(
	'param_name'  => 'rt_padding_right',
	'heading'     => __( 'Padding Right','rt_theme' ),
	'description' => __( 'Set padding right value (px,%) Default is 0px','rt_theme' ),
	'type'        => 'rt_number',
	'group'       => __( 'Paddings','rt_theme' ),
	"dependency"  => array(
							"element" => "rt_row_paddings",
							"value" => array("true")
						),	
));	



rt_vc_add_param( array('vc_row','vc_row_inner'), array(
	'param_name'  => 'id',
	'heading'     => __('ID','rt_theme' ),
	'description' => __('Unique ID','rt_theme' ),
	'type'        => 'textfield',
	'value'       => '',
));	

rt_vc_add_param( array('vc_row','vc_row_inner'), array(
	'param_name'  => 'class',
	'heading'     => __('Class','rt_theme' ),
	'description' => __('CSS Class Name','rt_theme' ),
	'type'        => 'textfield',
));	


//background options
rt_vc_add_param( array('vc_row','vc_row_inner'), array(
	'param_name'  => 'rt_bg_image',
	'heading'     => __( 'Background Image','rt_theme' ),
	'description' => __( 'Select a background image','rt_theme' ),
	'type'        => 'attach_image',	
	'group'       => __( 'Background Options','rt_theme' ),
	'value'	     => '',
));

rt_vc_add_param( array('vc_row','vc_row_inner'), array(
	'param_name'  => 'rt_bg_effect',
	'heading'     => __( 'Background Effect','rt_theme' ),
	'description' => __( 'Select the background effect','rt_theme' ),
	'type'        => 'dropdown',
	"value"       => array(
						__("Classic",'rt_theme') => "classic",
						_x("Custom Height", 'Admin Panel','rt_theme') => "custom_height",
						__("Parallax Image",'rt_theme') => "parallax",
					),				
	'group'       => __( 'Background Options','rt_theme' ),
	'save_always' => true
));

rt_vc_add_param( array('vc_row','vc_row_inner'), array(
	'param_name'  => 'rt_bg_custom_height',
	'heading'     => _x( 'Custom Height', 'Admin Panel','rt_theme' ),
	'description' => _x( 'Give a height value for the background (px,%)', 'Admin Panel','rt_theme' ),
	'type'        => 'textfield',
	'group'       => _x( 'Background Options', 'Admin Panel','rt_theme' ),
	"dependency"  => array(
							"element" => "rt_bg_effect",
							"value" => array("custom_height")
						),	
));

rt_vc_add_param( array('vc_row','vc_row_inner'), array(
	'param_name'  => 'rt_bg_custom_alignment',
	'heading'     => _x( 'Background Alignment', 'Admin Panel','rt_theme' ),
	'description' => _x( 'Alignment of the custom background', 'Admin Panel','rt_theme' ),
	'type'        => 'dropdown', 
	"value"       => array(		
						_x("Top",'Admin Panel','rt_theme') => "top",
						_x("Bottom",'Admin Panel','rt_theme') => "bottom",
					),	
	'group'       => _x( 'Background Options', 'Admin Panel','rt_theme' ),
	'save_always' => true,
	"dependency"  => array(
							"element" => "rt_bg_effect",
							"value" => array("custom_height","shape")
						),		
));

rt_vc_add_param( array('vc_row','vc_row_inner'), array(
	'param_name'  => 'rt_bg_color',
	'heading'     => __( 'Background Color','rt_theme' ),
	'description' => __( 'Select a background color for the content row','rt_theme' ),
	'type'        => 'colorpicker',
	'group'       => __( 'Background Options','rt_theme' ),
));

rt_vc_add_param( array('vc_row','vc_row_inner'), array(
	'param_name'  => 'rt_bg_overlay_color',
	'heading'     => __( 'Background Overlay Color','rt_theme' ),
	'description' => __( 'Select a overlay color for the background. It is useful when you have a background image or background video. Select a transparent color.','rt_theme' ),
	'type'        => 'colorpicker',
	'group'       => __( 'Background Options','rt_theme' ),
));

rt_vc_add_param( array('vc_row','vc_row_inner'), array(
	'param_name'  => 'rt_bg_parallax_effect',
	'heading'     => __( 'Parallax Effect','rt_theme' ),
	'description' => __( 'Select the parallax style set repeat mode direction for the background image.','rt_theme' ),
	'type'        => 'dropdown',
	"value"       => array(		
						__("Horizontally, from left to right",'rt_theme') => "1",  
						__("Horizontally, from right to left",'rt_theme') => "2",  
						__("Vertically, from top to bottom",'rt_theme') => "3",  
						__("Vertically, from bottom to top",'rt_theme') => "4",  																
					),
	'group'       => __( 'Background Options','rt_theme' ),
	"dependency"  => array(
							"element" => "rt_bg_effect",
							"value" => array("parallax")
						),
	'save_always' => true											
));

rt_vc_add_param( array('vc_row','vc_row_inner'), array(
	'param_name'  => 'rt_pspeed',
	'heading'     => __( 'Parallax Speed','rt_theme' ),
	'description' => __( 'Select the parallax effect speed','rt_theme' ),
	'type'        => 'dropdown',
	"value"       => array(		
								"fast - 6x" => "6",  
								"5x" => "5",  
								"4x" => "4",  
								"3x" => "3",  
								"2x" => "2",  
								"slow - 1x" => "1",
							),
	'group'       => __( 'Background Options','rt_theme' ),
	"dependency"  => array(
							"element" => "rt_bg_effect",
							"value" => array("parallax")
						),
));



rt_vc_add_param( array('vc_row','vc_row_inner'), array(
	'param_name'  => 'rt_bg_image_repeat',
	'heading'     => __( 'Background Repeat','rt_theme' ),
	'description' => __( 'Select and set repeat mode direction for the background image.','rt_theme' ),
	'type'        => 'dropdown',
	"value"       => array(		
						__("Tile","rt_theme") => "repeat",
						__("Tile Horizontally","rt_theme") => "repeat-x",
						__("Tile Vertically","rt_theme") => "repeat-y",
						__("No Repeat","rt_theme") => "no-repeat"
					),
	'group'       => __( 'Background Options','rt_theme' ),
	'save_always' => true
));

rt_vc_add_param( array('vc_row','vc_row_inner'), array(
	'param_name'  => 'rt_bg_size',
	'heading'     => __( 'Background Image Size','rt_theme' ),
	'description' => __( 'Select and set size / coverage behaviour for the background image.','rt_theme' ),
	'type'        => 'dropdown', 
	"value"       => array(		
						__("Cover","rt_theme") => "cover",
						__("Auto","rt_theme") => "auto auto",						
						__("Contain","rt_theme") => "contain",
						__("100%","rt_theme") => "100% auto",
						__("50%","rt_theme") => "50% auto",
						__("25%","rt_theme") => "25% auto",
					),	
	'group'       => __( 'Background Options','rt_theme' ),
	'save_always' => true
));

rt_vc_add_param( array('vc_row','vc_row_inner'), array(
	'param_name'  => 'rt_bg_position',
	'heading'     => __( 'Background Position','rt_theme' ),
	'description' => __( 'Select a positon for the background image.','rt_theme' ),
	'type'        => 'dropdown', 
	"value"       => array(		
						__("Right Top","rt_theme") => "right top",
						__("Right Center","rt_theme") => "right center",
						__("Right Bottom","rt_theme") => "right bottom",
						__("Left Top","rt_theme") => "left top",
						__("Left Center","rt_theme") => "left center",
						__("Left Bottom","rt_theme") => "left bottom",
						__("Center Top","rt_theme") => "center top",
						__("Center Center","rt_theme") => "center center",
						__("Center Bottom","rt_theme") => "center bottom",
					),	
	'group'       => __( 'Background Options','rt_theme' ),
	'save_always' => true
));

rt_vc_add_param( array('vc_row','vc_row_inner'), array(
	'param_name'  => 'rt_bg_attachment',
	'heading'     => __( 'Background Attachment','rt_theme' ),
	'description' => __( 'Select and set fixed or scroll mode for the background image.','rt_theme' ),
	'type'        => 'dropdown', 
	"value"       => array(		
						__("Scroll","rt_theme") => "scroll",
						__("Fixed","rt_theme") => "fixed",  
					),	
	'group'       => __( 'Background Options','rt_theme' ),
	"dependency"  => array(
							"element" => "rt_bg_effect",
							"value" => array("classic")
						),			
	'save_always' => true
));					

//video background options
rt_vc_add_param( array('vc_row','vc_row_inner'), array(
	'param_name'  => 'rt_bg_video_format',
	'heading'     => __( 'Video Format','rt_theme' ),
	'type'        => 'dropdown',
	"value"       => array(
						__("Self Hosted HTML5 Video",'rt_theme') => "self-hosted",
						__("YouTube",'rt_theme') => "youtube",						
					),				
	'group'       => __( 'Video Background Options','rt_theme' ),
	'save_always' => true
));

rt_vc_add_param( array('vc_row','vc_row_inner'), array(
	'param_name'  => 'rt_bg_video_mp4',
	'heading'     => __( 'MP4 File URL / ID','rt_theme' ),
	'description' => __( 'Enter your video (.mp4) file URL or ID','rt_theme' ),
	'type'        => 'textfield',	
	'group'       => __( 'Video Background Options','rt_theme' ),
	"dependency"  => array(
							"element" => "rt_bg_video_format",
							"value" => array("self-hosted")
						),		
));

rt_vc_add_param( array('vc_row','vc_row_inner'), array(
	'param_name'  => 'rt_bg_video_webm',
	'heading'     => __( 'WEBM File URL / ID','rt_theme' ),
	'description' => __( 'Enter your video (.webm) file URL or ID','rt_theme' ),
	'type'        => 'textfield',	
	'group'       => __( 'Video Background Options','rt_theme' ),
	"dependency"  => array(
							"element" => "rt_bg_video_format",
							"value" => array("self-hosted")
						),		
));

rt_vc_add_param( array('vc_row','vc_row_inner'), array(
	'param_name'  => 'rt_bg_video_youtube',
	'heading'     => __( 'Youtube Video URL','rt_theme' ),
	'description' => __( 'Enter your youtube video URL','rt_theme' ),
	'type'        => 'textfield',	
	'group'       => __( 'Video Background Options','rt_theme' ),
	"dependency"  => array(
							"element" => "rt_bg_video_format",
							"value" => array("youtube")
						),		
));
?>