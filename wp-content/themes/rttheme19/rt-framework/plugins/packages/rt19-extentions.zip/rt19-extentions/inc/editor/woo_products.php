<?php
/*
*
* WooCommerce Products
*
*/ 

vc_map(
	array(
		'base'        => 'woo_products',
		'name'        => __( 'WooCommerce Products','rt_theme' ),
		'icon'        => 'rt_theme wc',
		'category'    => array(__( 'Content','rt_theme' ), __( 'Theme Addons','rt_theme' ), 'WooCommerce'),
		'description' => __( 'Displays WooCommerce products with selected parameters','rt_theme' ),
		'params'      => array(

 
							array(
								'param_name'  => 'id',
								'heading'     => __('ID','rt_theme' ),
								'description' => __('Unique ID','rt_theme' ),
								'type'        => 'textfield',
								'value'       => ''
							),

							array(
								'param_name'  => 'class',
								'heading'     => __('Class','rt_theme' ),
								'description' => __('CSS Class Name','rt_theme' ),
								'type'        => 'textfield'
							),

							array(
								'param_name'  => 'list_layout',
								'heading'     => __( 'Layout','rt_theme' ),
								"description" => __("Column layout for the list",'rt_theme'),
								'type'        => 'dropdown',
								"value"       => array(
													"1/6" => "1/6", 
													"1/4" => "1/4",
													"1/3" => "1/3",
													"1/2" => "1/2",
													"1/1" => "1/1"
												),
								'save_always' => true
							),
 
							array(
								'param_name'  => 'pagination',
								'heading'     => __( 'Pagination','rt_theme' ),
								"description" => __("Splits the list into pages",'rt_theme'),
								'type'        => 'dropdown',
								"value"       => array(
													"False" => "false", 
													"True" => "true"													
												),
								'save_always' => true						
							),


							array(
								'param_name'  => 'list_orderby',
								'heading'     => __( 'List Order By','rt_theme' ),
								"description" => __("Sorts the posts by this parameter",'rt_theme'),
								'type'        => 'dropdown',
								"value"       => array(
													__('Date','rt_theme') => 'date',
													__('Author','rt_theme') => 'author',
													__('Title','rt_theme') => 'title',
													__('Modified','rt_theme') => 'modified',
													__('ID','rt_theme') => 'ID',
													__('Randomized','rt_theme') => 'rand',
												),
								'save_always' => true
							),

							array(
								'param_name'  => 'list_order',
								'heading'     => __( 'List Order','rt_theme' ),
								"description" => __("Designates the ascending or descending order of the list_orderby parameter",'rt_theme'),
								'type'        => 'dropdown',
								"value"       => array(
													__('Descending','rt_theme') => 'DESC',
													__('Ascending','rt_theme') => 'ASC',
												),
								'save_always' => true
							),

							array(
								'param_name'  => 'item_per_page',
								'heading'     => __('Amount of post per page','rt_theme' ),
								'type'        => 'textfield'
							),


							array(
								'param_name'  => 'categories',
								'heading'     => __( 'Categories','rt_theme' ),
								"description" => __("List posts of selected categories only.",'rt_theme'),
								'type'        => 'dropdown_multi',
								"value"       => array_merge(array(__('All Categories','rt_theme')=>""),array_flip(rt_get_woo_product_category_ids())),
							),
			
						)
	)
);	

?>