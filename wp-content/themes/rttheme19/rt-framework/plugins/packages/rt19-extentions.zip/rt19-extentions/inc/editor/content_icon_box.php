<?php
/*
*
* Content Box With Icons
* [content_icon_box] 
*
*/ 

vc_map(
	array(
		'base'        => 'content_icon_box',
		'name'        => __( 'Content Box With Icon','rt_theme' ),
		'icon'        => 'rt_theme content_box',
		'category'    => array(__( 'Content','rt_theme' ), __( 'Theme Addons','rt_theme' )),
		'description' => __( 'Add a content box with an icon','rt_theme' ),
		'params'      => array(

							array(
								'param_name'  => 'heading',
								'heading'     => __( 'Heading','rt_theme' ),
								'description' => '',
								'type'        => 'textfield',
								'holder'      => 'div',
								'value'       => __( 'Box Heading','rt_theme' ),
								'holder'      => 'div',
								'group'       => 'Text',
								'save_always' => true
							), 

							array(
								'param_name'  => 'heading_size',
								'heading'     => __( 'Heading Size','rt_theme' ),
								'description' => __( 'Select the size of the heading tag','rt_theme' ),
								'type'        => 'dropdown',
								'group'       => 'Text',
								"value"       => array(
													"H1" => "h1", 
													"H2" => "h2", 
													"H3" => "h3", 
													"H4" => "h4", 
													"H5" => "h5", 
													"H6" => "h6", 
												),
								'save_always' => true
							),

							array(
								'param_name'  => 'content',
								'heading'     => __( 'Text','rt_theme' ),
								'description' => '',
								'type'        => 'textarea_html',
								'holder'      => 'div',
								'value'       => __( 'I am text block. Click edit button to change this text.','rt_theme' ),
								'group'       => 'Text',
								'holder'      => 'div',
								'save_always' => true
							),

							array(
								'param_name'  => 'icon_name',
								'heading'     => __('Icon Name','rt_theme' ),
								'description' => __('Click inside the field to select an icon or type the icon name','rt_theme' ),
								'type'        => 'textfield',
								'class'       => 'icon_selector',
								'group'       => 'Icon'
							),

							array(
								'param_name'  => 'icon_position',
								'heading'     => __( 'Icon Position','rt_theme' ),
								'description' => __( 'Select an Icon Position','rt_theme' ),
								'type'        => 'dropdown',
								"value"       => array(
													__("Left",'rt_theme') => "left",
													__("Right",'rt_theme') => "right", 
													__("Top",'rt_theme') => "top", 
												),
								'group'       => 'Icon',
								'save_always' => true,
							),

							array(
								'param_name'  => 'icon_style',
								'heading'     => __( 'Icon Style','rt_theme' ),
								'description' => __( 'Select an Icon Style','rt_theme' ),
								'type'        => 'dropdown',
								"value"       => array(
													__("Style One",'rt_theme') => "style-1",
													__("Style Two",'rt_theme') => "style-2", 
													__("Style Three",'rt_theme') => "style-3", 
													__("Style Four",'rt_theme') => "style-4", 
												),
								'group'       => 'Icon',
								'save_always' => true,
							),

							array(
								'param_name'  => 'link',
								'heading'     => __('Link','rt_theme' ),
								'type'        => 'textfield',
								'value'       => '',
								'group'       => 'Link'
							),

							array(
								'param_name'  => 'link_text',
								'heading'     => __('Link Text','rt_theme' ),
								'type'        => 'textfield',
								'value'       => '',
								'group'       => 'Link'
							),

							array(
								'param_name'  => 'link_target',
								'heading'     => __('Link Target','rt_theme' ),
								'type'        => 'dropdown',
								"value"       => array(
													__("Same Tab",'rt_theme') => "_self",
													__("New Tab",'rt_theme') => "_blank", 
												),
								'group'       => 'Link',
								'save_always' => true,
							),										

							array(
								'param_name'  => 'id',
								'heading'     => __('ID','rt_theme' ),
								'description' => __('Unique ID','rt_theme' ),
								'type'        => 'textfield',
								'value'       => ''
							),

							array(
								'param_name'  => 'class',
								'heading'     => __('Class','rt_theme' ),
								'description' => __('CSS Class Name','rt_theme' ),
								'type'        => 'textfield'
							),


							)
	)
);
		

?>