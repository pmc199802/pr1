<?php
/*
*
* Latest News
*
*/ 

vc_map(
	array(
		'base'        => 'rt_latest_news',
		'name'        => __( 'Latest News','rt_theme' ),
		'icon'        => 'rt_theme latest_news',
		'category'    => array(__( 'Content','rt_theme' ), __( 'Theme Addons','rt_theme' )),
		'description' => __( 'Displays blog posts with latest news style','rt_theme' ),
		'params'      => array(

 							array(
								'param_name'  => 'style',
								'heading'     => __( 'Style','rt_theme' ),
								'type'        => 'dropdown',
								"value"       => array(
													__('Style 1 - Big Dates','rt_theme') => '1',
													__('Style 2- Featured Images','rt_theme') => '2', 
												),
								'save_always' => true
							),

							array(
								'param_name'  => 'show_dates',
								'heading'     => __('Display Post Dates?','rt_theme' ),
								'type'        => 'checkbox',
								"value"       => array(
													__("Yes",'rt_theme') => "true"
								),			
								"dependency"  => array(
									"element" => "style",
									"value" => array("2")
								),										
							),

							array(
								'param_name'  => 'id',
								'heading'     => __('ID','rt_theme' ),
								'description' => __('Unique ID','rt_theme' ),
								'type'        => 'textfield',
								'value'       => ''
							),

							array(
								'param_name'  => 'max_item',
								'heading'     => __('Amount of item to display','rt_theme' ),
								'type'        => 'rt_number',
								'value'       => '10',
								'save_always' => true
							),


							array(
								'param_name'  => 'excerpt_length',
								'heading'     => __('Excerpt Length','rt_theme' ),
								'type'        => 'rt_number',
								'value'       => '100',
								'save_always' => true
							),

							array(
								'param_name'  => 'list_orderby',
								'heading'     => __( 'List Order By','rt_theme' ),
								"description" => __("Sorts the posts by this parameter",'rt_theme'),
								'type'        => 'dropdown',
								"value"       => array(
													__('Date','rt_theme') => 'date',
													__('Author','rt_theme') => 'author',
													__('Title','rt_theme') => 'title',
													__('Modified','rt_theme') => 'modified',
													__('ID','rt_theme') => 'ID',
													__('Randomized','rt_theme') => 'rand',
												),
								'save_always' => true
							),

							array(
								'param_name'  => 'list_order',
								'heading'     => __( 'List Order','rt_theme' ),
								"description" => __("Designates the ascending or descending order of the list_orderby parameter",'rt_theme'),
								'type'        => 'dropdown',
								"value"       => array(
													__('Descending','rt_theme') => 'DESC',
													__('Ascending','rt_theme') => 'ASC',
												),
								'save_always' => true
							),


							array(
								'param_name'  => 'categories',
								'heading'     => __( 'Categories','rt_theme' ),
								"description" => __("List posts of selected categories only.",'rt_theme'),
								'type'        => 'dropdown_multi',
								"value"       => array_merge(array(__('All Categories','rt_theme')=>""),array_flip(rt_get_categories())),
								'save_always' => true
							),


							/* Featured Images */
							array(
								'param_name'  => 'image_width',
								'heading'     => __('Featured Image Max Width','rt_theme' ),
								'type'        => 'textfield',
								'value'       => 250,
								"dependency"  => array(
													"element" => "style",
													"value" => array("2")
												),
								'save_always' => true
							),

							array(
								'param_name'  => 'image_height',
								'heading'     => __('Featured Image Max Height','rt_theme' ),
								'type'        => 'textfield',
								'value'       => 250,
								"dependency"  => array(
													"element" => "style",
													"value" => array("2")
												),
								'save_always' => true
							),


			
						)
	)
);	

?>