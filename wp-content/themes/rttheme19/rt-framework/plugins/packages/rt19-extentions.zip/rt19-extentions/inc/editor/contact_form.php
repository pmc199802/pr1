<?php
/*
*
* Contact Form Shortcode 
*
*/ 

global $current_user; 

vc_map(
	array(
		'base'        => 'contact_form',
		'name'        => __( 'Contact Form','rt_theme' ),
		'icon'        => 'rt_theme contact_form',
		'category'    => array( __( 'Theme Addons','rt_theme' ) ),
		'description' => __( 'Displays a contact form','rt_theme' ),
		'params'      => array(

							array(
								'param_name'  => 'email',
								'heading'     => __('Email','rt_theme' ),
								'description' => __('The contact form will be submited to this email.','rt_theme' ),
								'type'        => 'textfield',
								'value'       => $current_user->user_email,
								'save_always' => true
							),

							array(
								'param_name'  => 'security',
								'heading' => __( 'Security Question','rt_theme' ),
								'type'        => 'checkbox',
								"value"       => array(
													__("Enable the security question to prevent spam messages.",'rt_theme') => "true",
												),
							),

							array(
								'param_name'  => 'confirmation',
								'heading' => _x( 'Confirmation Checkbox', 'Admin Panel','rt_theme' ),
								'type'        => 'checkbox',
								"value"       => array(
													_x("Enable the confirmation checkbox for GDPR.", 'Admin Panel','rt_theme') => "true",
												),
							),
							
							array(
								'param_name'  => 'id',
								'heading'     => __('ID','rt_theme' ),
								'description' => __('Unique ID','rt_theme' ),
								'type'        => 'textfield',
								'value'       => ''
							),

							array(
								'param_name'  => 'class',
								'heading'     => __('Class','rt_theme' ),
								'description' => __('CSS Class Name','rt_theme' ),
								'type'        => 'textfield'
							)
			
						)
	)
);	

?>