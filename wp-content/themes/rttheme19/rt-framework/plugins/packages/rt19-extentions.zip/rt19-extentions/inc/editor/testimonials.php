<?php
/*
*
* Testimonials
*
*/ 

vc_map(
	array(
		'base'        => 'testimonial_box',
		'name'        => __( 'Testimonials','rt_theme' ),
		'icon'        => 'rt_theme testimonial',
		'category'    => array(__( 'Content','rt_theme' ), __( 'Theme Addons','rt_theme' )),
		'description' => __( 'Displays testimonial posts','rt_theme' ),
		'params'      => array(

 
							array(
								'param_name'  => 'id',
								'heading'     => __('ID','rt_theme' ),
								'description' => __('Unique ID','rt_theme' ),
								'type'        => 'textfield',
								'value'       => ''
							),

							array(
								'param_name'  => 'class',
								'heading'     => __('Class','rt_theme' ),
								'description' => __('CSS Class Name','rt_theme' ),
								'type'        => 'textfield'
							),


							array(
								'param_name'  => 'list_layout',
								'heading'     => __( 'Layout','rt_theme' ),
								"description" => __("Column layout for the list",'rt_theme'),
								'type'        => 'dropdown',
								"value"       => array(
													"1/1" => "1/1",
													"1/2" => "1/2",
													"1/3" => "1/3",
													"1/4" => "1/4",
													"1/6" => "1/6", 
												),
								'save_always' => true
							),
 
 							array(
								'param_name'  => 'style',
								'heading'     => __( 'Style','rt_theme' ),
								'type'        => 'dropdown',
								"value"       => array(
													__("Left Aligned Text","rt_theme") => "left",
													__("Centered Small Text ","rt_theme") => "center",
													__("Centered Big Text ","rt_theme") => "center big"
												),
								'save_always' => true
							),

							
							array(
								'param_name'  => 'client_images',
								'heading'     => __( 'Display Client Images','rt_theme' ),
								'type'        => 'dropdown',
								"value"       => array(
													__("Enabled","rt_theme") => "true", 
													__("Disabled","rt_theme") => "false"													
												),
								'save_always' => true										
							),
							
							array(
								'param_name'  => 'pagination',
								'heading'     => __( 'Pagination','rt_theme' ),
								"description" => __("Splits the list into pages",'rt_theme'),
								'type'        => 'dropdown',
								"value"       => array(
													"False" => "false", 
													"True" => "true"													
												),
								'save_always' => true										
							),

/*
							array(
								'param_name'  => 'ids',
								'heading'     => __( 'Select Testimonials','rt_theme' ),
								"description" => __("List posts of selected posts only.",'rt_theme'),
								'type'        => 'dropdown_multi',
								"value"       => array_merge(array(__('All Testimonials','rt_theme')=>""),array_flip(RTTheme::rt_get_testimonial_list())),
							),
*/

							array(
								'param_name'  => 'categories',
								'heading'     => __( 'Categories','rt_theme' ),
								"description" => __("List posts of selected categories only.",'rt_theme'),
								'type'        => 'dropdown_multi',
								"value"       => array_merge(array(__('All Categories','rt_theme')=>""),array_flip(rt_get_testimonial_categories())),
							),
							
							array(
								'param_name'  => 'list_orderby',
								'heading'     => __( 'List Order By','rt_theme' ),
								"description" => __("Sorts the posts by this parameter",'rt_theme'),
								'type'        => 'dropdown',
								"value"       => array(
													__('Date','rt_theme') => 'date',
													__('Author','rt_theme') => 'author',
													__('Title','rt_theme') => 'title',
													__('Modified','rt_theme') => 'modified',
													__('ID','rt_theme') => 'ID',
													__('Randomized','rt_theme') => 'rand',
												),
								'save_always' => true
							),

							array(
								'param_name'  => 'list_order',
								'heading'     => __( 'List Order','rt_theme' ),
								"description" => __("Designates the ascending or descending order of the list_orderby parameter",'rt_theme'),
								'type'        => 'dropdown',
								"value"       => array(
													__('Descending','rt_theme') => 'DESC',
													__('Ascending','rt_theme') => 'ASC',
												),
								'save_always' => true
							),

							array(
								'param_name'  => 'item_per_page',
								'heading'     => __('Amount of post per page','rt_theme' ),
								'type'        => 'textfield'
							),
 
			
						)
	)
);	

?>